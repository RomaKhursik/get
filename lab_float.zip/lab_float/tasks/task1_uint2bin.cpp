#include "task1_uint2bin.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <string>

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

int main() {
    const unsigned int tests[] = { 0u, 1u, 2u, 5u, 255u, 256u, 1024u, 4096u,
                                   65535u, 65536u, 0x00FF00FFu, 0xDEADBEEFu,
                                   2147483648u, 4294967295u };
    const int count = sizeof(tests) / sizeof(tests[0]);

    std::ofstream f = open_data("task1_bits.txt");
    f << "# число;hex;биты\n";

    std::cout << "Задание 1: unsigned int в двоичном виде\n";
    char bits[33], hex[11];

    for (int i = 0; i < count; i++) {
        to_bin32(tests[i], bits);
        std::snprintf(hex, 11, "0x%08X", tests[i]);
        f << tests[i] << ";" << hex << ";" << bits << "\n";
        std::cout << std::setw(12) << tests[i] << "  " << hex << "  " << bits << "\n";
    }

    // ловушка: результат маски -- 0 или 2^k, а не 0/1
    unsigned int x = 0x4Cu;
    std::cout << "\nx = " << x << ":\n";
    for (int k = 0; k <= 3; k++)
        std::cout << "  x & (1 << " << k << ") = " << std::setw(2) << (x & (1u << k))
                  << "   ((x >> " << k << ") & 1) = " << ((x >> k) & 1u) << "\n";

    std::cout << "Данные сохранены: Data/task1_bits.txt\n";
    return 0;
}
