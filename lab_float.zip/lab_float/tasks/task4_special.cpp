#include "task1_uint2bin.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <limits>
#include <string>

union FloatBits  { float f; unsigned int u; };
union DoubleBits { double d; unsigned long long u; };

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

void add_line(std::ofstream& f, const char* what, const char* bits, const char* hex, const char* note) {
    f << what << ";" << bits << ";" << hex << ";" << note << "\n";
    std::cout << std::setw(30) << what << "  " << bits << "  " << hex << "  " << note << "\n";
}

int main() {
    std::ofstream f = open_data("task4_special.txt");
    f << "# что;биты;hex;пояснение\n";

    // порядок из всех единиц зарезервирован: мантисса 0 -> inf, мантисса != 0 -> nan
    std::cout << "Задание 4: особые значения\n\n=== float ===\n";
    char bits[65], hex[19];

    const float inf_f = std::numeric_limits<float>::infinity();
    const float nan_f = std::numeric_limits<float>::quiet_NaN();

    struct { const char* what; float value; const char* note; } fv[] = {
        { "+inf (infinity())",   inf_f,                "порядок=255, мантисса=0" },
        { "-inf (-infinity())",  -inf_f,               "то же, но знак = 1" },
        { "+inf (переполнение)", std::numeric_limits<float>::max() * 2.0f, "FLT_MAX * 2" },
        { "+inf (1.0f / 0.0f)",  1.0f / 0.0f,          "деление на ноль" },
        { "-inf (-1.0f / 0.0f)", -1.0f / 0.0f,         "деление на ноль" },
        { "nan (quiet_NaN())",   nan_f,                "порядок=255, мантисса != 0" },
        { "nan (0.0f / 0.0f)",   0.0f / 0.0f,          "неопределённость" },
        { "nan (inf - inf)",     inf_f - inf_f,        "неопределённость" },
        { "nan (sqrtf(-1.0f))",  std::sqrt(-1.0f),     "вне области определения" },
    };
    for (int i = 0; i < (int)(sizeof(fv) / sizeof(fv[0])); i++) {
        FloatBits t;
        t.f = fv[i].value;
        to_bin32(t.u, bits);
        std::snprintf(hex, 11, "0x%08X", t.u);
        add_line(f, fv[i].what, bits, hex, fv[i].note);
    }

    FloatBits snan;                                  // nan, собранный из битов
    snan.u = 0x7F800001u;
    to_bin32(snan.u, bits);
    std::snprintf(hex, 11, "0x%08X", snan.u);
    add_line(f, "snan (собран из битов)", bits, hex, "мантисса = 1");

    std::cout << "\n=== double ===\n";
    const double inf_d = std::numeric_limits<double>::infinity();
    const double nan_d = std::numeric_limits<double>::quiet_NaN();

    struct { const char* what; double value; const char* note; } dv[] = {
        { "+inf",             inf_d,           "порядок=2047, мантисса=0" },
        { "-inf",             -inf_d,          "знак = 1" },
        { "+inf (1.0 / 0.0)", 1.0 / 0.0,       "деление на ноль" },
        { "nan (quiet_NaN())", nan_d,          "порядок=2047, мантисса != 0" },
        { "nan (0.0 / 0.0)",   0.0 / 0.0,      "неопределённость" },
        { "nan (inf - inf)",   inf_d - inf_d,  "неопределённость" },
    };
    for (int i = 0; i < (int)(sizeof(dv) / sizeof(dv[0])); i++) {
        DoubleBits t;
        t.d = dv[i].value;
        to_bin64(t.u, bits);
        std::snprintf(hex, 19, "0x%016llX", t.u);
        add_line(f, dv[i].what, bits, hex, dv[i].note);
    }

    std::cout << "\ninf + inf = inf, inf - inf = nan, 1/inf = 0, inf*0 = nan, nan != nan\n"
                 "проверять надо std::isnan: знак у nan не гарантируется\n";
    std::cout << "Данные сохранены: Data/task4_special.txt\n";
    return 0;
}
