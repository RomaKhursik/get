#include "task1_uint2bin.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <string>

// приведение float к unsigned округлило бы число, поэтому смотрим те же байты через union
union FloatBits  { float f; unsigned int u; };
union DoubleBits { double d; unsigned long long u; };

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

void write_float(std::ofstream& f, float x) {
    FloatBits b;
    b.f = x;

    unsigned int sign = b.u >> 31;
    unsigned int e_raw = (b.u >> 23) & 0xFF;
    unsigned int frac = b.u & 0x7FFFFF;
    int e = (int)e_raw - 127;

    char bits[33], hex[11];
    to_bin32(b.u, bits);
    std::snprintf(hex, 11, "0x%08X", b.u);

    double m = (double)frac / 8388608.0;                 // 2^23
    double restored = std::ldexp(1.0 + m, e);            // 1.m * 2^e
    if (sign) restored = -restored;

    char val[32];
    std::snprintf(val, 32, "%.9g", x);

    f << val << ";" << bits << ";" << hex << ";" << sign << ";"
      << e_raw << ";" << e << ";" << std::fixed << std::setprecision(9) << m << "\n";
    f.unsetf(std::ios::floatfield);

    std::cout << std::setw(15) << val << "  " << bits << "  " << hex
              << "   e=" << std::setw(4) << e << "   сборка = " << std::setprecision(9) << restored
              << (restored == (double)x ? "  ok" : "  РАСХОЖДЕНИЕ!") << "\n";
}

void write_double(std::ofstream& f, double x) {
    DoubleBits b;
    b.d = x;

    unsigned long long sign = b.u >> 63;
    unsigned int e_raw = (unsigned int)((b.u >> 52) & 0x7FF);
    unsigned long long frac = b.u & 0xFFFFFFFFFFFFFull;
    int e = (int)e_raw - 1023;

    char bits[65], hex[19];
    to_bin64(b.u, bits);
    std::snprintf(hex, 19, "0x%016llX", b.u);

    double m = (double)frac / 4503599627370496.0;        // 2^52
    double restored = std::ldexp(1.0 + m, e);
    if (sign) restored = -restored;

    char val[40];
    std::snprintf(val, 40, "%.17g", x);

    f << val << ";" << bits << ";" << hex << ";" << sign << ";"
      << e_raw << ";" << e << ";" << std::fixed << std::setprecision(17) << m << "\n";
    f.unsetf(std::ios::floatfield);

    std::cout << std::setw(22) << val << "  " << hex << "  e=" << std::setw(5) << e
              << (restored == x ? "  сборка ok" : "  РАСХОЖДЕНИЕ!") << "\n";
}

int main() {
    std::ofstream ff = open_data("task2_float.txt");
    std::ofstream fd = open_data("task2_double.txt");
    ff << "# значение;биты;hex;знак;порядок_e_raw;e;мантисса_дробь\n";
    fd << "# значение;биты;hex;знак;порядок_e_raw;e;мантисса_дробь\n";

    std::cout << "Задание 2: float (1 + 8 + 23) и double (1 + 11 + 52)\n\n=== float ===\n";
    const float fvals[] = { 1.0f, 2.0f, 0.5f, 0.1f, 0.2f, -0.2f, 3.5f, 3.14f,
                            1.0e-30f, 1.17549435e-38f, 9.99999968e+37f };
    for (int i = 0; i < (int)(sizeof(fvals) / sizeof(fvals[0])); i++)
        write_float(ff, fvals[i]);

    std::cout << "\n=== double ===\n";
    const double dvals[] = { 1.0, 0.1, 0.2, -0.2, 3.14, 1.0e100 };
    for (int i = 0; i < (int)(sizeof(dvals) / sizeof(dvals[0])); i++)
        write_double(fd, dvals[i]);

    std::cout << "\n0.2f = 0 01111100 10011001100110011001101 = 0x3E4CCCCD\n"
                 "  порядок 124 -> e = -3, мантисса даёт 1.6000000238...\n"
                 "  сборка: 1.6000000238 * 2^-3 = 0.20000000298... -- точного 0.2 нет\n";
    std::cout << "Данные сохранены: Data/task2_float.txt, Data/task2_double.txt\n";
    return 0;
}
