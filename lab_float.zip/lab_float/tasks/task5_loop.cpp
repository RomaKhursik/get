#include "task1_uint2bin.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

union FloatBits { float f; unsigned int u; };

float next_float(float x) {              // соседний float: +1 к битовому шаблону
    FloatBits b;
    b.f = x;
    b.u = b.u + 1;
    return b.f;
}

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

int main(int argc, char** argv) {
    const float probes[] = { 16777214.0f, 16777215.0f, 16777216.0f,
                             16777218.0f, 33554432.0f, 67108864.0f };
    const int count = sizeof(probes) / sizeof(probes[0]);

    std::ofstream fu = open_data("task5_ulp.txt");
    fu << "# x;следующий float;ULP;x+1==x\n";
    std::cout << "Задание 5: бесконечный цикл на float-счётчике\n";
    std::cout << std::fixed << std::setprecision(0);
    std::cout << "           x     следующий float    ULP   x + 1.0f == x ?\n";

    for (int i = 0; i < count; i++) {
        float x = probes[i];
        float nx = next_float(x);
        int same = (x + 1.0f == x) ? 1 : 0;
        fu << std::fixed << std::setprecision(0) << x << ";" << nx << ";"
           << (nx - x) << ";" << same << "\n";
        std::cout << std::setw(12) << x << std::setw(19) << nx << std::setw(7) << (nx - x)
                  << "   " << (same ? "ДА -- шаг потерялся" : "нет") << "\n";
    }

    float counter = 0.0f;
    long long steps = 0;
    while (counter + 1.0f != counter) { counter += 1.0f; steps++; }

    std::ofstream fs = open_data("task5_stop.txt");
    fs << "# шагов;значение счётчика, на котором он застрял\n";
    fs << steps << ";" << std::fixed << std::setprecision(0) << counter << "\n";

    // закрываем файлы до демонстрации зависания: при Ctrl+C буфер иначе потеряется
    fu.close();
    fs.close();

    char bits[33];
    FloatBits b;
    b.f = counter;
    to_bin32(b.u, bits);
    std::cout << "\nсчётчик сделал " << steps << " шагов и застрял на " << counter << " = 2^24\n"
              << "биты этого значения: " << bits << "\n";

    // настоящий бесконечный цикл -- только с аргументом hang
    if (argc > 1 && std::string(argv[1]) == "hang") {
        float c = 16777216.0f;
        std::cout << "\nwhile (counter < 1.0e9f) counter += 1.0f;  -- выход Ctrl+C\n";
        std::cout.flush();
        long long it = 0;
        while (c < 1.0e9f) {
            c += 1.0f;
            if (++it % 10000000LL == 0)
                std::cout << "  итераций " << it << ", counter = " << c << "\n";
        }
    } else {
        std::cout << "\nзависание: ./tasks/task5_loop hang\n";
    }

    std::cout << "Данные сохранены: Data/task5_stop.txt, Data/task5_ulp.txt\n";
    return 0;
}
