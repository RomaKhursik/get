#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <string>

typedef unsigned long long ull;

ull my_pow(ull x, ull n) {
    ull result = 1;
    for (ull i = 0; i < n; i++) result *= x;
    return result;
}

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

int main() {
    const ull BASE = 3;
    const int N = 40;                        // 3^41 уже не влезает в unsigned long long

    std::ofstream ff = open_data("task0_float.txt");
    std::ofstream fd = open_data("task0_double.txt");
    ff << "# степень;my_pow;std_pow_float\n";
    fd << "# степень;my_pow;std_pow_double\n";

    std::cout << "Задание 0: my_pow(3,n) против std::pow(3,n)\n";
    std::cout << " n       my_pow       pow<float>       pow<double>\n";

    for (int n = 0; n <= N; n++) {
        ull exact = my_pow(BASE, (ull)n);
        // оба аргумента приводим к float, иначе вызовется double-версия pow
        float  pf = std::pow((float)BASE, (float)n);
        double pd = std::pow((double)BASE, (double)n);

        ff << n << ";" << exact << ";" << std::fixed << std::setprecision(0) << pf << "\n";
        fd << n << ";" << exact << ";" << std::fixed << std::setprecision(0) << pd << "\n";
        ff.unsetf(std::ios::floatfield);
        fd.unsetf(std::ios::floatfield);

        std::cout << std::setw(3) << n << std::setw(14) << exact
                  << std::setw(15) << std::fixed << std::setprecision(0) << pf
                  << std::setw(16) << pd << "\n";
        std::cout.unsetf(std::ios::floatfield);
    }

    int nf = 0; while (std::isfinite(std::pow(3.0f, (float)nf))) nf++;
    int nd = 0; while (std::isfinite(std::pow(3.0, (double)nd))) nd++;
    std::cout << "\nmy_pow: точна до n = " << N << ", дальше переполнение ull\n";
    std::cout << "std::pow<float>: inf при n = " << nf << ", double: при n = " << nd << "\n";
    std::cout << "Данные сохранены: Data/task0_float.txt, Data/task0_double.txt\n";
    return 0;
}
