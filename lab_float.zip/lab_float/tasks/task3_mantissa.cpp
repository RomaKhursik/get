#include "task1_uint2bin.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <string>

typedef unsigned long long ull;

union FloatBits  { float f; unsigned int u; };
union DoubleBits { double d; unsigned long long u; };

ull my_pow(ull x, ull n) {
    ull result = 1;
    for (ull i = 0; i < n; i++) result *= x;
    return result;
}

int bits_needed(ull v) {
    int b = 0;
    while (v > 0) { b++; v >>= 1; }
    return b;
}

std::ofstream open_data(const std::string& name) {
    std::ofstream f("Data/" + name);
    if (!f.is_open()) f.open("../Data/" + name);
    return f;
}

int main() {
    const ull BASE = 3;
    const int N = 40;

    std::ofstream ff = open_data("task3_float.txt");
    std::ofstream fd = open_data("task3_double.txt");
    ff << "# степень;my_pow;std_pow_float;биты\n";
    fd << "# степень;my_pow;std_pow_double;биты\n";

    std::cout << "Задание 3: переполнение мантиссы (float: 24 значащих бита, double: 53)\n";
    char bits[65];

    for (int n = 0; n <= N; n++) {
        ull exact = my_pow(BASE, (ull)n);

        FloatBits bf;
        bf.f = std::pow((float)BASE, (float)n);
        to_bin32(bf.u, bits);
        ff << n << ";" << exact << ";" << std::fixed << std::setprecision(0) << bf.f
           << ";" << bits << "\n";
        ff.unsetf(std::ios::floatfield);

        DoubleBits bd;
        bd.d = std::pow((double)BASE, (double)n);
        to_bin64(bd.u, bits);
        fd << n << ";" << exact << ";" << std::fixed << std::setprecision(0) << bd.d
           << ";" << bits << "\n";
        fd.unsetf(std::ios::floatfield);

        std::cout << std::setw(3) << n << std::setw(22) << exact << "  нужно бит: "
                  << std::setw(3) << bits_needed(exact)
                  << (bits_needed(exact) > 24 ? "  float уже не влезает" : "") << "\n";
    }

    std::cout << "\nfloat: первая потеря при n = 16 (3^16 = 43046721, 26 бит, в памяти 43046720)\n"
                 "double: при n = 34 (3^34 = 16677181699666569, 54 бита, в памяти 16677181699666570)\n";
    std::cout << "Данные сохранены: Data/task3_float.txt, Data/task3_double.txt\n";
    return 0;
}
