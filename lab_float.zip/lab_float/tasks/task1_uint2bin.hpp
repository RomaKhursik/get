#pragma once

inline void to_bin32(unsigned int x, char* buf) {
    for (int i = 0; i < 32; i++) buf[i] = ((x >> (31 - i)) & 1u) ? '1' : '0';
    buf[32] = '\0';
}

inline void to_bin64(unsigned long long x, char* buf) {
    for (int i = 0; i < 64; i++) buf[i] = ((x >> (63 - i)) & 1ull) ? '1' : '0';
    buf[64] = '\0';
}
