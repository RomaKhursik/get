# Задание 0: таблицы my_pow против std::pow.
# Данные: Data/task0_float.txt, Data/task0_double.txt -> pictures/task0_*.png
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, os.pardir, "Data")


def read_data(filename):
    path = os.path.join(DATA, filename)
    if not os.path.exists(path):
        raise SystemExit("Нет файла " + path + "\nСначала запустите: tasks/task0_pow.cpp")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line.split(";"))
    return rows


def draw_table(headers, rows, title, out_name, col_widths=None, fontsize=9,
               mono_cols=(), height_per_row=0.30):
    fig, ax = plt.subplots(figsize=(11, 1.0 + height_per_row * (len(rows) + 1)))
    ax.axis("off")
    ax.set_title(title, fontsize=13, pad=14)

    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center",
                     colWidths=col_widths, bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#e8e8e8")
            cell.get_text().set_weight("bold")
        if col in mono_cols:
            cell.get_text().set_fontfamily("DejaVu Sans Mono")
        cell.get_text().set_fontsize(fontsize - 1 if row == 0 else fontsize)

    out = os.path.join(HERE, out_name)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("сохранено:", out_name)


def with_check(rows):
    result = []
    for r in rows:
        ok = int(r[1]) == int(r[2])
        result.append([r[0], r[1], r[2], "OK" if ok else "потеря точности"])
    return result


rows = read_data("task0_float.txt")
draw_table(
    headers=["степень n", "my_pow(3, n)", "std::pow(3.0f, n)", "проверка"],
    rows=with_check(rows),
    title="Задание 0. Таблица 1: float -- первая ошибка при n = 16",
    out_name="task0_float.png",
    col_widths=[0.14, 0.28, 0.30, 0.28],
    mono_cols=(0, 1, 2),
)

rows = read_data("task0_double.txt")
draw_table(
    headers=["степень n", "my_pow(3, n)", "std::pow(3.0, n)", "проверка"],
    rows=with_check(rows),
    title="Задание 0. Таблица 2: double -- первая ошибка при n = 34",
    out_name="task0_double.png",
    col_widths=[0.14, 0.28, 0.30, 0.28],
    mono_cols=(0, 1, 2),
)
