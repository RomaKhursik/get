# Задание 3: таблицы переполнения мантиссы (4 столбца: степень, my_pow, std::pow, биты).
# Данные: Data/task3_float.txt, Data/task3_double.txt -> pictures/task3_*.png
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, os.pardir, "Data")


def read_data(filename):
    path = os.path.join(DATA, filename)
    if not os.path.exists(path):
        raise SystemExit("Нет файла " + path + "\nСначала запустите: tasks/task3_mantissa.cpp")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line.split(";"))
    return rows


def draw_table(headers, rows, title, out_name, col_widths=None, fontsize=9,
               mono_cols=(), figure_width=13, height_per_row=0.30):
    fig, ax = plt.subplots(figsize=(figure_width, 1.0 + height_per_row * (len(rows) + 1)))
    ax.axis("off")
    ax.set_title(title, fontsize=13, pad=14)

    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center",
                     colWidths=col_widths, bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#e8e8e8")
            cell.get_text().set_weight("bold")
        if col in mono_cols:
            cell.get_text().set_fontfamily("DejaVu Sans Mono")
        cell.get_text().set_fontsize(fontsize - 1 if row == 0 else fontsize)

    out = os.path.join(HERE, out_name)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("сохранено:", out_name)


def bits_needed(v):
    n = 0
    while v > 0:
        n += 1
        v >>= 1
    return n


rows = read_data("task3_float.txt")
rows_for_table = []
for r in rows:
    need = bits_needed(int(r[1]))
    rows_for_table.append([r[0], r[1], r[2], r[3], str(need),
                           "влезает" if need <= 24 else "НЕ влезает (есть 24)"])

draw_table(
    headers=["степень n", "my_pow(3, n)", "std::pow в float",
             "биты результата std::pow", "нужно бит", "влезает в мантиссу float?"],
    rows=rows_for_table,
    title="Задание 3. float: переполнение мантиссы (мантисса 23 + неявная 1 = 24 бита)",
    out_name="task3_float.png",
    col_widths=[0.09, 0.20, 0.19, 0.28, 0.09, 0.15],
    fontsize=8,
    mono_cols=(0, 1, 2, 3, 4),
)

# 64 бита не влезают в строку: переносим после 12-го символа (знак + порядок)
rows = read_data("task3_double.txt")
rows_for_table = []
for r in rows:
    need = bits_needed(int(r[1]))
    bits_two_lines = r[3][:12] + "\n" + r[3][12:]
    rows_for_table.append([r[0], r[1], r[2], bits_two_lines, str(need),
                           "влезает" if need <= 53 else "НЕ влезает (есть 53)"])

draw_table(
    headers=["степень n", "my_pow(3, n)", "std::pow в double",
             "биты результата std::pow", "нужно бит", "влезает в мантиссу double?"],
    rows=rows_for_table,
    title="Задание 3. double: переполнение мантиссы (мантисса 52 + неявная 1 = 53 бита)",
    out_name="task3_double.png",
    col_widths=[0.09, 0.19, 0.19, 0.30, 0.09, 0.14],
    fontsize=8,
    mono_cols=(0, 1, 2, 3, 4),
    height_per_row=0.42,
)
