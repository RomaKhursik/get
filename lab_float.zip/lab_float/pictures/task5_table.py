# Задание 5: таблицы про шаг между float и про то, где застревает счётчик.
# Данные: Data/task5_ulp.txt, Data/task5_stop.txt -> pictures/task5_*.png
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, os.pardir, "Data")


def read_data(filename):
    path = os.path.join(DATA, filename)
    if not os.path.exists(path):
        raise SystemExit("Нет файла " + path + "\nСначала запустите: tasks/task5_loop.cpp")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line.split(";"))
    return rows


def draw_table(headers, rows, title, out_name, col_widths=None, fontsize=10,
               mono_cols=(), figure_width=11, height_per_row=0.36, note=None):
    fig, ax = plt.subplots(figsize=(figure_width, 1.0 + height_per_row * (len(rows) + 1)))
    ax.axis("off")
    ax.set_title(title, fontsize=13, pad=14)

    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center",
                     colWidths=col_widths, bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#e8e8e8")
            cell.get_text().set_weight("bold")
        if col in mono_cols:
            cell.get_text().set_fontfamily("DejaVu Sans Mono")

    if note:
        ax.text(0.5, -0.02, note, transform=ax.transAxes, ha="center", va="top",
                fontsize=10, color="#333333")

    out = os.path.join(HERE, out_name)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("сохранено:", out_name)


rows_for_table = []
for r in read_data("task5_ulp.txt"):
    rows_for_table.append([r[0], r[1], r[2],
                           "ДА -- шаг потерялся" if r[3] == "1" else "нет"])

draw_table(
    headers=["x", "следующий float", "ULP (расстояние)", "x + 1.0f == x ?"],
    rows=rows_for_table,
    title="Задание 5. Расстояние между соседними float растёт с числом",
    out_name="task5_ulp.png",
    col_widths=[0.20, 0.22, 0.22, 0.36],
    fontsize=11,
    mono_cols=(0, 1, 2),
)

steps, value = read_data("task5_stop.txt")[0]

draw_table(
    headers=["шагов сделал счётчик", "значение, на котором застрял", "это 2^24"],
    rows=[[steps, value, "16777216"]],
    title="Задание 5. Бесконечный цикл: счётчик замирает и больше не растёт",
    out_name="task5_stop.png",
    col_widths=[0.32, 0.36, 0.32],
    fontsize=11,
    mono_cols=(0, 1, 2),
    height_per_row=0.55,
    note=("Дальше: while (counter < 1.0e9f) counter += 1.0f;  --  условие выхода\n"
          "недостижимо, потому что counter + 1.0f == counter.  Это и есть вечный цикл."),
)
