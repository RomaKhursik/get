# Задание 2: таблицы разбора float и double на знак / порядок / мантиссу.
# Данные: Data/task2_float.txt, Data/task2_double.txt -> pictures/task2_*.png
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, os.pardir, "Data")


def read_data(filename):
    path = os.path.join(DATA, filename)
    if not os.path.exists(path):
        raise SystemExit("Нет файла " + path + "\nСначала запустите: tasks/task2_float2bin.cpp")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line.split(";"))
    return rows


def draw_table(headers, rows, title, out_name, col_widths=None, fontsize=9,
               mono_cols=(), figure_width=12, height_per_row=0.30):
    fig, ax = plt.subplots(figsize=(figure_width, 1.0 + height_per_row * (len(rows) + 1)))
    ax.axis("off")
    ax.set_title(title, fontsize=13, pad=14)

    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center",
                     colWidths=col_widths, bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#e8e8e8")
            cell.get_text().set_weight("bold")
        if col in mono_cols:
            cell.get_text().set_fontfamily("DejaVu Sans Mono")
        cell.get_text().set_fontsize(fontsize - 1 if row == 0 else fontsize)

    out = os.path.join(HERE, out_name)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("сохранено:", out_name)


draw_table(
    headers=["значение", "биты: знак | порядок(8) | мантисса(23)", "hex",
             "знак", "e_raw", "e", "мантисса (дробь)"],
    rows=read_data("task2_float.txt"),
    title="Задание 2. float в памяти: 1 + 8 + 23 бита",
    out_name="task2_float.png",
    col_widths=[0.12, 0.40, 0.11, 0.07, 0.08, 0.06, 0.16],
    mono_cols=(0, 1, 2, 3, 4, 5, 6),
    height_per_row=0.34,
)

# 64 бита не влезают в строку: переносим после 12-го символа (знак + порядок)
rows = read_data("task2_double.txt")
rows_for_table = []
for r in rows:
    bits_two_lines = r[1][:12] + "\n" + r[1][12:]
    rows_for_table.append([r[0], bits_two_lines, r[2], r[3], r[4], r[5], r[6]])

draw_table(
    headers=["значение", "биты: знак | порядок(11) | мантисса(52)\n(разбиты по 32)",
             "hex", "знак", "e_raw", "e", "мантисса (дробь)"],
    rows=rows_for_table,
    title="Задание 2. double в памяти: 1 + 11 + 52 бита",
    out_name="task2_double.png",
    col_widths=[0.15, 0.35, 0.15, 0.06, 0.08, 0.06, 0.15],
    fontsize=8,
    mono_cols=(0, 1, 2, 3, 4, 5, 6),
    height_per_row=0.42,
)
