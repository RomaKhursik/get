# Задание 4: таблицы особых значений inf, -inf, nan.
# Данные: Data/task4_special.txt -> pictures/task4_*.png
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, os.pardir, "Data")


def read_data(filename):
    path = os.path.join(DATA, filename)
    if not os.path.exists(path):
        raise SystemExit("Нет файла " + path + "\nСначала запустите: tasks/task4_special.cpp")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line.split(";"))
    return rows


def draw_table(headers, rows, title, out_name, col_widths=None, fontsize=9,
               mono_cols=(), figure_width=14, height_per_row=0.34):
    fig, ax = plt.subplots(figsize=(figure_width, 1.0 + height_per_row * (len(rows) + 1)))
    ax.axis("off")
    ax.set_title(title, fontsize=13, pad=14)

    table = ax.table(cellText=rows, colLabels=headers, cellLoc="center",
                     colWidths=col_widths, bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("#e8e8e8")
            cell.get_text().set_weight("bold")
        if col in mono_cols:
            cell.get_text().set_fontfamily("DejaVu Sans Mono")
        cell.get_text().set_fontsize(fontsize - 1 if row == 0 else fontsize)

    out = os.path.join(HERE, out_name)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("сохранено:", out_name)


# в файле и float (32 бита), и double (64) -- разводим по длине битовой строки
rows_float, rows_double = [], []
for r in read_data("task4_special.txt"):
    what, bits, hexval, note = r
    if len(bits) == 32:
        rows_float.append([what, bits, hexval, note])
    else:
        rows_double.append([what, bits[:12] + "\n" + bits[12:], hexval, note])

draw_table(
    headers=["что за значение", "биты", "hex", "пояснение"],
    rows=rows_float,
    title="Задание 4. Особые значения float (порядок = 255 -- зарезервирован)",
    out_name="task4_float.png",
    col_widths=[0.20, 0.42, 0.15, 0.23],
    mono_cols=(1, 2),
    height_per_row=0.36,
)

draw_table(
    headers=["что за значение", "биты (разбиты по 32)", "hex", "пояснение"],
    rows=rows_double,
    title="Задание 4. Особые значения double (порядок = 2047 -- зарезервирован)",
    out_name="task4_double.png",
    col_widths=[0.20, 0.42, 0.16, 0.22],
    fontsize=8,
    mono_cols=(1, 2),
    height_per_row=0.46,
)

draw_table(
    headers=["что за значение", "биты", "hex", "пояснение"],
    rows=[r for r in rows_float if r[0].startswith(("+inf", "-inf", "nan (quiet", "nan (0.0"))],
    title="Задание 4. Шпаргалка: inf, -inf и nan во float",
    out_name="task4_special.png",
    col_widths=[0.20, 0.42, 0.15, 0.23],
    mono_cols=(1, 2),
    height_per_row=0.36,
)
